from django.apps import AppConfig


class TrailConfig(AppConfig):
    name = 'trail'
